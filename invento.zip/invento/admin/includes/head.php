<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arusha Laptops</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/welix.css">
    <!-- <link rel="stylesheet" href="../assets/css/welix-dark.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="../assets/DataTables/datatables.min.css">
    <link rel="stylesheet" href="../assets/fontawasome5/css/all.min.css">
    <link rel="shortcut icon" href="../assets/img/fav.ico" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../assets/js/jquery-3.6.0.js"></script>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> -->
    <script src="../assets/js/welix.js"></script>
    <script src="../assets/DataTables/datatables.min.js"></script>
    <script src="../assets/fontawasome5/js/all.min.js"></script>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    
</head>