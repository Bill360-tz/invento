$(document).ready(function () {
    $("#sumTable").DataTable();
  });