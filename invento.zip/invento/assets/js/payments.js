$(document).ready(function () {
    $("#payTable").DataTable();
  });