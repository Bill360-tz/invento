<?php
header("location: admin/")
?>